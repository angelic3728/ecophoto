---
name: '功能需求 ✨'
about: 对 ant-design-charts 的需求或建议
title: '👑 [需求]'
labels: '👑 Feature'
assignees: ''
---

### 🥰 需求描述 [详细地描述需求，让大家都能理解]

### 🧐 解决方案 [如果你有解决方案，在这里清晰地阐述]

### 🚑 其他信息 [如截图等其他信息可以贴在这里]
