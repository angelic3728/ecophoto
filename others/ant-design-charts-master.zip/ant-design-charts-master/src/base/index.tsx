import ErrorBoundary from '../errorBoundary';

export { ErrorBoundary };
