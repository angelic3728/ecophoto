

## title: API

## 自定义主题

G2Plot 继承 G2 的自定义主题机制，[详细文档](https://g2.antv.vision/en/docs/manual/developer/registertheme)。

G2 提供了自定义主题机制以允许用户切换、定义图表主题。包括：

-   定义全新的主题结构
-   使用主题样式表，实现主题的快速定制
