module.exports = {
  setupFiles: ['jest-canvas-mock', './test/setup.js'],
  testEnvironment: 'jsdom',
};
